"""
Celery tasks for RenovisionAI.

This module defines background tasks invoked by the API. The primary task
`generate_render` takes a job ID, fetches the corresponding job record from
the database, calls an external generative API (e.g., Replicate SDXL), saves
the result to storage and updates the job record with the resulting URL.

The current implementation stubs the actual generation with a placeholder
operation for demonstration. In a real deployment you would integrate the
Replicate SDK here using the REPLICATE_API_TOKEN【624640778666419†L406-L421】.
"""
from __future__ import annotations

import os
import time
import uuid
from typing import Optional

from sqlmodel import Session, select, SQLModel, create_engine

from .celery_utils import celery_app
from .models import RenderJob, Project

try:
    # Import the replicate client if available. If not installed the task will
    # fall back to a dummy implementation below. The replicate library is
    # optional and will only be used when present and a REPLICATE_API_TOKEN is
    # configured in the environment.
    import replicate  # type: ignore
except ImportError:
    replicate = None  # type: ignore


# Use a synchronous engine for Celery tasks; Celery processes cannot easily
# reuse the async engine from the main app. The DATABASE_URL may use
# psycopg2 driver which is synchronous by default.
SYNC_DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql+psycopg2://postgres:postgres@db:5432/renovision"
)
sync_engine = create_engine(SYNC_DATABASE_URL, echo=False)


@celery_app.task(name="generate_render")
def generate_render(job_id: str) -> Optional[str]:
    """Background task that performs the image generation.

    Args:
        job_id: The UUID of the RenderJob record as a string.

    Returns:
        The URL of the generated image if successful, otherwise None.
    """
    # Convert job_id to UUID
    try:
        job_uuid = uuid.UUID(job_id)
    except ValueError:
        return None

    with Session(sync_engine) as session:
        job = session.exec(select(RenderJob).where(RenderJob.id == job_uuid)).first()
        if job is None:
            return None

        # Mark as running
        job.status = "running"
        session.add(job)
        session.commit()

        # If the replicate client is available and a token is configured, call
        # the SDXL model to generate an "after" image. Otherwise fall back
        # to a no‑op that simply returns the original before URL. This allows
        # the application to run locally without external network access but
        # enables real generation in production when Replicate is configured.
        after_url: Optional[str] = None
        api_token = os.getenv("REPLICATE_API_TOKEN")
        if replicate and api_token:
            try:
                # Authenticate using the environment variable. The replicate
                # client reads REPLICATE_API_TOKEN automatically.
                # Choose a stable version of the SDXL model. See
                # https://replicate.com/stability-ai/sdxl for the latest version
                model_version = os.getenv(
                    "REPLICATE_MODEL_VERSION",
                    "stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b",
                )
                # Build the prompt. Prepend the style to encourage the model to
                # generate the requested interior design aesthetic. You can
                # customize the prompt strength via environment variables if
                # desired.
                prompt = job.style
                # Run the model using the replicate client. The
                # use_file_output=False flag returns URL strings instead of
                # file objects. Note: some versions of the client return a
                # list of outputs.
                outputs = replicate.run(
                    model_version,
                    input={
                        "prompt": prompt,
                        "image": open(job.before_url, "rb"),
                        "prompt_strength": float(os.getenv("REPLICATE_PROMPT_STRENGTH", "0.8")),
                        "num_inference_steps": int(os.getenv("REPLICATE_STEPS", "50")),
                        "guidance_scale": float(os.getenv("REPLICATE_GUIDANCE", "7.5")),
                    },
                    use_file_output=False,
                )
                # Extract the first output URL
                if isinstance(outputs, list) and outputs:
                    after_url = outputs[0]
                elif outputs:
                    after_url = outputs
            except Exception:
                # If generation fails, leave after_url as None and fall back
                # below. The job will remain pending until a valid URL is
                # provided. Logging can be added here for debugging.
                after_url = None
        # Fallback: without Replicate, simply use the original image
        if after_url is None:
            # Simulate processing delay
            time.sleep(5)
            after_url = job.before_url
        # Update job record
        job.after_url = after_url
        job.status = "completed"
        # Update timestamp to current UTC time
        from datetime import datetime
        job.updated_at = datetime.utcnow()
        session.add(job)
        # Create or update a Project record with this render
        project = session.exec(select(Project).where(Project.id == job.id)).first()
        if project is None:
            project = Project(
                id=job.id,
                user_id=job.user_id,
                before_url=job.before_url,
                after_url=after_url,
            )
        else:
            project.after_url = after_url
        session.add(project)
        session.commit()

        return after_url