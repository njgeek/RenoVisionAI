"""
Project management routes.

These endpoints allow authenticated users to list their previous renders and
associated metadata.
"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

from ..database import get_session
from ..dependencies import get_current_user
from ..models import Project, ProjectRead, User

router = APIRouter()


@router.get("/projects", response_model=List[ProjectRead])
async def list_projects(
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> list[ProjectRead]:
    """Return a list of all projects belonging to the current user."""
    result = await session.exec(
        select(Project).where(Project.user_id == current_user.id).order_by(Project.created_at.desc())
    )
    projects = result.all()
    return [ProjectRead.from_orm(project) for project in projects]