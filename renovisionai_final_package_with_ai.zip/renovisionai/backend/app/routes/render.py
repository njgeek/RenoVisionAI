"""
Endpoints for submitting and tracking image render jobs.

Users with available credits can submit a render job by uploading an
image and specifying a style. Jobs are executed asynchronously via a
Celery task. Progress can be polled via the status endpoint.
"""
from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

from ..database import get_session
from ..dependencies import get_current_user
from ..models import RenderJob, User, RenderStatus, RenderRequest
from ..tasks import generate_render

router = APIRouter()


UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/tmp/renovision_uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


@router.post("/render", response_model=RenderStatus, status_code=status.HTTP_202_ACCEPTED)
async def submit_render(
    style: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> RenderStatus:
    """Submit a new render job.

    Checks that the user has available credits, stores the uploaded file,
    creates a RenderJob record, enqueues a Celery task and decrements
    the user's remaining credits.
    """
    # Refresh subscription info
    await session.refresh(current_user, attribute_names=["subscription"])
    sub = current_user.subscription
    if sub is None or sub.credits_left <= 0:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="No credits left")

    # Save uploaded file to disk
    suffix = Path(file.filename).suffix if file.filename else ".jpg"
    dest_path = UPLOAD_DIR / f"{uuid.uuid4()}{suffix}"
    content = await file.read()
    with dest_path.open("wb") as out_file:
        out_file.write(content)
    before_url = dest_path.as_posix()

    # Create RenderJob
    job = RenderJob(
        user_id=current_user.id,
        style=style,
        before_url=before_url,
        status="pending",
    )
    session.add(job)

    # Decrement credits
    sub.credits_left -= 1
    session.add(sub)
    await session.commit()
    await session.refresh(job)

    # Enqueue Celery task
    generate_render.delay(str(job.id))

    return RenderStatus(job_id=job.id, status=job.status, after_url=None)


@router.get("/status/{job_id}", response_model=RenderStatus)
async def get_render_status(
    job_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> RenderStatus:
    """Return the status of a render job."""
    result = await session.exec(select(RenderJob).where(RenderJob.id == job_id))
    job = result.first()
    if job is None or job.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return RenderStatus(job_id=job.id, status=job.status, after_url=job.after_url)