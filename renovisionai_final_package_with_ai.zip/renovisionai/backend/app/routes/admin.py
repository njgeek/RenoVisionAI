"""
Admin routes for RenovisionAI.

This module exposes endpoints that allow an administrator to view user accounts
and overall usage statistics. Access to these endpoints is restricted based
on an admin email defined in the environment (ADMIN_EMAIL). Only the user
whose email matches this value will be permitted to call these routes.
"""
from __future__ import annotations

import os
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

from ..database import get_session
from ..models import User, Subscription, Project, RenderJob
from ..dependencies import get_current_user


router = APIRouter()


async def require_admin(
    current_user: User = Depends(get_current_user),
) -> User:
    """Ensure that the current user is the configured administrator.

    The administrator is determined by the ADMIN_EMAIL environment variable. If
    no admin email is configured the first registered user effectively
    becomes admin. If the current user's email does not match the admin email
    then a 403 Forbidden error is raised.
    """
    admin_email = os.getenv("ADMIN_EMAIL")
    if admin_email:
        if current_user.email.lower() != admin_email.lower():
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required")
    return current_user


@router.get("/users")
async def list_users(
    session: AsyncSession = Depends(get_session),
    _: User = Depends(require_admin),
) -> List[dict]:
    """Return a list of all registered users along with their subscription info.

    Each returned record contains the user's ID, email, first name, creation date,
    subscription tier and remaining credits. This information allows the admin to
    monitor subscription status and usage.
    """
    # Join User and Subscription tables to retrieve subscription details
    result = await session.exec(
        select(User, Subscription).join(Subscription, Subscription.user_id == User.id)
    )
    records = result.all()
    users = []
    for user, subscription in records:
        users.append(
            {
                "id": str(user.id),
                "email": user.email,
                "first_name": user.first_name,
                "created_at": user.created_at.isoformat(),
                "subscription_tier": subscription.tier.value,
                "credits_left": subscription.credits_left,
            }
        )
    return users


@router.get("/stats")
async def usage_stats(
    session: AsyncSession = Depends(get_session),
    _: User = Depends(require_admin),
) -> dict:
    """Return high‑level usage statistics for the application.

    The returned dictionary includes the total number of users, projects and
    render jobs. These figures help the administrator monitor overall system
    usage and growth.
    """
    user_count = await session.exec(select(User))
    project_count = await session.exec(select(Project))
    job_count = await session.exec(select(RenderJob))
    return {
        "user_count": len(user_count.all()),
        "project_count": len(project_count.all()),
        "render_job_count": len(job_count.all()),
    }