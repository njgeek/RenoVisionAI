// This component uses React hooks; mark it as a client component
"use client";

import { useRef, useState } from 'react';

interface UploadWidgetProps {
  onUpload: (file: File) => void;
}

/**
 * UploadWidget renders a dropzone-style file picker. Users can either drag and drop an image
 * into the designated area or click the “Choose Photo” button to open the file picker. When
 * a file is selected, the provided onUpload callback is invoked with the File object.
 */
const UploadWidget: React.FC<UploadWidgetProps> = ({ onUpload }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (fileList && fileList.length > 0) {
      onUpload(fileList[0]);
    }
  };

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      onUpload(files[0]);
    }
  };

  return (
    <div
      className={`flex flex-col items-center justify-center space-y-2 border-2 border-dashed rounded-lg p-6 cursor-pointer transition-colors ${
        dragActive ? 'border-primary bg-blue-50 dark:bg-gray-700' : 'border-gray-300 dark:border-gray-600'
      }`}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input
        type="file"
        accept="image/*"
        ref={inputRef}
        onChange={handleChange}
        className="hidden"
      />
      <p className="text-sm mb-2 select-none">
        Drag & drop a photo here or
      </p>
      <button
        type="button"
        onClick={(e) => {
          // Prevent triggering the container click as well
          e.stopPropagation();
          inputRef.current?.click();
        }}
        className="px-4 py-2 bg-primary text-white rounded hover:bg-blue-600"
      >
        Choose Photo
      </button>
    </div>
  );
};

export default UploadWidget;