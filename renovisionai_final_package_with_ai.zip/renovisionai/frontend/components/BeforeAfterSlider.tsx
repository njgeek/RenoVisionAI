// This component uses React state; mark as a client component
"use client";

import { useState } from 'react';

interface BeforeAfterSliderProps {
  beforeSrc: string;
  afterSrc: string;
}

const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ beforeSrc, afterSrc }) => {
  const [percent, setPercent] = useState(50);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPercent(parseInt(e.target.value, 10));
  };
  return (
    <div className="relative w-full max-w-xl mx-auto">
      <div className="overflow-hidden relative">
        <img src={afterSrc} alt="After" className="w-full" />
        <div
          className="absolute top-0 left-0 h-full overflow-hidden"
          style={{ width: `${percent}%` }}
        >
          <img src={beforeSrc} alt="Before" className="w-full" />
        </div>
      </div>
      <input
        type="range"
        min="0"
        max="100"
        value={percent}
        onChange={handleChange}
        className="w-full mt-2"
      />
    </div>
  );
};

export default BeforeAfterSlider;