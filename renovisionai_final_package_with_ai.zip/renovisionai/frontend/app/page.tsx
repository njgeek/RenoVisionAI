"use client";

// Mark this component as a client component so we can use React hooks and event handlers.

import UploadWidget from '../components/UploadWidget';
import BeforeAfterSlider from '../components/BeforeAfterSlider';
import Image from 'next/image';

import { useState, useEffect } from 'react';
import axios from 'axios';

export default function HomePage() {
  // Hold a preview of the user-selected image for the demo slider
  const [beforePreview, setBeforePreview] = useState<string | null>(null);
  // Hold the generated "after" image once the render job completes
  const [afterPreview, setAfterPreview] = useState<string | null>(null);
  // Track whether a render job is in progress
  const [isGenerating, setIsGenerating] = useState(false);
  // Style choices for the rendering. You can expand this list with
  // additional design aesthetics.
  const styles = ['Modern', 'Industrial', 'Rustic', 'Minimalist'];
  const [style, setStyle] = useState(styles[0]);

  const handleUpload = async (file: File) => {
    // Reset previous results
    setAfterPreview(null);
    // Show a local preview of the uploaded image
    const url = URL.createObjectURL(file);
    setBeforePreview(url);
    try {
      setIsGenerating(true);
      // Prepare form data to send to the backend. The API expects
      // a multipart/form-data request with fields `style` and `file`.
      const formData = new FormData();
      formData.append('style', style);
      formData.append('file', file);
      const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL;
      const res = await axios.post(
        `${apiBase}/render`,
        formData,
        {
          withCredentials: true,
          headers: { 'Content-Type': 'multipart/form-data' },
        }
      );
      const { job_id } = res.data;
      // Poll the status endpoint until the job completes
      const pollInterval = 3000;
      const poll = async () => {
        try {
          const statusRes = await axios.get(
            `${apiBase}/status/${job_id}`,
            { withCredentials: true }
          );
          const data = statusRes.data;
          if (data.status === 'completed' && data.after_url) {
            setAfterPreview(data.after_url);
            setIsGenerating(false);
          } else {
            setTimeout(poll, pollInterval);
          }
        } catch (err) {
          // If polling fails, stop trying and hide loading state
          setIsGenerating(false);
        }
      };
      poll();
    } catch (err) {
      setIsGenerating(false);
    }
  };

  // Revoke the object URL when the component unmounts or when a new file is chosen
  useEffect(() => {
    return () => {
      if (beforePreview) {
        URL.revokeObjectURL(beforePreview);
      }
    };
  }, [beforePreview]);

  return (
    <div className="space-y-12">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Visualize Your Remodel Today</h1>
        <p className="text-lg max-w-xl mx-auto">
          Upload a photo of your room and instantly preview stunning styles using AI. RenovisionAI helps you make
          confident design decisions before picking up a hammer.
        </p>
        <UploadWidget onUpload={handleUpload} />
      </section>
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">Choose Your Style</h2>
        <div className="flex justify-center mb-4">
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            className="px-3 py-2 border rounded dark:bg-gray-800 dark:border-gray-700"
          >
            {styles.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <h2 className="text-2xl font-semibold">See the difference</h2>
        {/* Show loading indicator while generating */}
        {isGenerating && (
          <p className="text-primary">Generating your remodel...</p>
        )}
        <BeforeAfterSlider
          beforeSrc={beforePreview || '/before.png'}
          afterSrc={afterPreview || '/after.png'}
        />
      </section>
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-center">Testimonials</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <blockquote className="p-4 border rounded-lg dark:border-gray-700">
            <p>
              “RenovisionAI saved us from costly design mistakes. Seeing our kitchen in three different styles before starting work was invaluable.”
            </p>
            <footer className="mt-2 text-sm">— Sarah, Homeowner</footer>
          </blockquote>
          <blockquote className="p-4 border rounded-lg dark:border-gray-700">
            <p>
              “As a contractor, I use RenovisionAI to show clients what’s possible. It helps close deals faster and sets clear expectations.”
            </p>
            <footer className="mt-2 text-sm">— Mike, Contractor</footer>
          </blockquote>
        </div>
      </section>
    </div>
  );
}