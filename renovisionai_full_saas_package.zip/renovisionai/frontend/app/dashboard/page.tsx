"use client";
import { useEffect, useState } from 'react';
import axios from 'axios';
import UploadWidget from '../../components/UploadWidget';

interface Project {
  id: string;
  before_url: string;
  after_url?: string;
  created_at: string;
}

interface UserInfo {
  id: string;
  email: string;
  first_name?: string;
  created_at: string;
  credits_left: number;
  subscription_tier: string;
}

export default function DashboardPage() {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(false);
  const [style, setStyle] = useState('Modern');

  const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL;

  const fetchData = async () => {
    try {
      const userRes = await axios.get(`${apiBase}/me`, { withCredentials: true });
      setUser(userRes.data);
      const projRes = await axios.get(`${apiBase}/projects`, { withCredentials: true });
      setProjects(projRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUpload = async (file: File) => {
    if (!user) return;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('style', style);
    setLoading(true);
    try {
      const res = await axios.post(`${apiBase}/render`, formData, {
        withCredentials: true,
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      const jobId: string = res.data.job_id;
      // Poll job status until completed
      const checkStatus = async () => {
        const statusRes = await axios.get(`${apiBase}/status/${jobId}`, { withCredentials: true });
        const { status: jobStatus } = statusRes.data;
        if (jobStatus === 'completed') {
          await fetchData();
          setLoading(false);
        } else {
          setTimeout(checkStatus, 2000);
        }
      };
      checkStatus();
    } catch (error) {
      console.error('Error submitting render', error);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      {user && (
        <div className="p-4 border rounded-lg dark:border-gray-700">
          <p>
            Signed in as <strong>{user.email}</strong>
          </p>
          <p>
            Plan: {user.subscription_tier} — Credits left: {user.credits_left}
          </p>
        </div>
      )}
      <div className="p-4 border rounded-lg dark:border-gray-700 space-y-4">
        <h2 className="text-xl font-semibold">New Render</h2>
        <div className="flex items-center space-x-4">
          <label htmlFor="style">Style:</label>
          <select
            id="style"
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            className="border rounded px-2 py-1 dark:bg-gray-800 dark:border-gray-700"
          >
            <option value="Modern">Modern</option>
            <option value="Rustic">Rustic</option>
            <option value="Minimalist">Minimalist</option>
          </select>
        </div>
        <UploadWidget onUpload={handleUpload} />
        {loading && <p className="text-primary">Rendering... Please wait.</p>}
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-4">Your Projects</h2>
        {projects.length === 0 && <p>No projects yet.</p>}
        <div className="grid md:grid-cols-3 gap-4">
          {projects.map((proj) => (
            <div key={proj.id} className="border rounded-lg p-2 dark:border-gray-700">
              <p className="text-sm text-gray-500">{new Date(proj.created_at).toLocaleString()}</p>
              <div className="mt-2 space-y-1">
                <img src={proj.before_url} alt="Before" className="w-full h-40 object-cover rounded" />
                {proj.after_url ? (
                  <img src={proj.after_url} alt="After" className="w-full h-40 object-cover rounded" />
                ) : (
                  <p className="text-center text-sm text-gray-500">In progress...</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}