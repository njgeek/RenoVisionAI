"use client";

// Mark this component as a client component so we can use React hooks and event handlers.

import UploadWidget from '../components/UploadWidget';
import BeforeAfterSlider from '../components/BeforeAfterSlider';
import Image from 'next/image';

import { useState, useEffect } from 'react';

export default function HomePage() {
  // Hold a preview of the user-selected image for the demo slider
  const [beforePreview, setBeforePreview] = useState<string | null>(null);

  const handleUpload = (file: File) => {
    const url = URL.createObjectURL(file);
    setBeforePreview(url);
  };

  // Revoke the object URL when the component unmounts or when a new file is chosen
  useEffect(() => {
    return () => {
      if (beforePreview) {
        URL.revokeObjectURL(beforePreview);
      }
    };
  }, [beforePreview]);

  return (
    <div className="space-y-12">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Visualize Your Remodel Today</h1>
        <p className="text-lg max-w-xl mx-auto">
          Upload a photo of your room and instantly preview stunning styles using AI. RenovisionAI helps you make
          confident design decisions before picking up a hammer.
        </p>
        <UploadWidget onUpload={handleUpload} />
      </section>
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">See the difference</h2>
        <BeforeAfterSlider
          beforeSrc={beforePreview || '/before.png'}
          afterSrc="/after.png"
        />
      </section>
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-center">Testimonials</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <blockquote className="p-4 border rounded-lg dark:border-gray-700">
            <p>
              “RenovisionAI saved us from costly design mistakes. Seeing our kitchen in three different styles before starting work was invaluable.”
            </p>
            <footer className="mt-2 text-sm">— Sarah, Homeowner</footer>
          </blockquote>
          <blockquote className="p-4 border rounded-lg dark:border-gray-700">
            <p>
              “As a contractor, I use RenovisionAI to show clients what’s possible. It helps close deals faster and sets clear expectations.”
            </p>
            <footer className="mt-2 text-sm">— Mike, Contractor</footer>
          </blockquote>
        </div>
      </section>
    </div>
  );
}