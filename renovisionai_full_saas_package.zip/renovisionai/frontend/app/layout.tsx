import './globals.css';
import { Metadata } from 'next';
import NavBar from '../components/NavBar';
import Footer from '../components/Footer';
import { ReactNode } from 'react';

export const metadata: Metadata = {
  title: 'RenovisionAI',
  description: 'See your home transformed before renovation',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <NavBar />
        <main className="flex-1 container mx-auto px-4 py-8">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}