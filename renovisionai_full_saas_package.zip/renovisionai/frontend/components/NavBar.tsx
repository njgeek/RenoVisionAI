// This component uses React hooks, so mark it as a client component
"use client";

import Link from 'next/link';
import { useState, useEffect } from 'react';

const NavBar = () => {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Load theme preference from localStorage
    const stored = localStorage.getItem('theme');
    setDarkMode(stored === 'dark');
  }, []);

  const toggleDark = () => {
    const newDark = !darkMode;
    setDarkMode(newDark);
    if (newDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  return (
    <nav className="w-full bg-white dark:bg-gray-800 shadow">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-3">
          {/* Apply invert/brightness filter in dark mode so the logo is visible on dark backgrounds */}
          <img
            src="/logo_cropped.png"
            alt="RenoVisionAI logo"
            className="h-10 w-auto dark:invert dark:brightness-150"
          />
          {/* Use accent color in dark mode for better contrast */}
          <span className="text-2xl font-bold text-primary dark:text-accent">RenovisionAI</span>
        </Link>
        <div className="flex items-center space-x-6">
          <Link href="/pricing" className="text-sm font-medium hover:text-primary transition-colors">Pricing</Link>
          <Link href="/dashboard" className="text-sm font-medium hover:text-primary transition-colors">Dashboard</Link>
          <Link href="/admin" className="text-sm font-medium hover:text-primary transition-colors">Admin</Link>
          <div className="flex items-center space-x-4">
            <Link href="/login" className="text-sm font-medium hover:underline">Login</Link>
            <Link
              href="/signup"
              className="text-sm px-3 py-1 rounded-md bg-primary text-white hover:bg-blue-600 transition-colors"
            >
              Sign Up
            </Link>
          </div>
          <button
            onClick={toggleDark}
            className="ml-2 px-2 py-1 rounded border border-primary text-primary dark:border-accent dark:text-accent"
          >
            {darkMode ? 'Light' : 'Dark'}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;