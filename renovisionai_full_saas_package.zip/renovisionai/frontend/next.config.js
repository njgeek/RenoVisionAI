/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Remove unused experimental flags. Next.js App Router is enabled by default
  // in Next.js 14; specifying unrecognized keys here will cause build warnings.
  images: {
    domains: [process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/^https?:\/\//, '') || 'localhost'],
  },
};

module.exports = nextConfig;