"""
Entry point for the Celery worker.

This module imports the Celery application defined in `celery_utils.py`
so that tasks are registered and can be executed by the worker process.
"""
from .celery_utils import celery_app  # noqa: F401