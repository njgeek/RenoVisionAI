"""
Database and Pydantic models for RenovisionAI.

These models define the structure of the database tables via SQLModel and
provide request and response schemas for FastAPI endpoints. The models
implement a simple subscription system with three tiers and store
information about render jobs submitted by users.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime, timedelta
from typing import Optional

from sqlmodel import SQLModel, Field, Relationship
from pydantic import BaseModel, EmailStr


class SubscriptionTier(str, enum.Enum):
    """Enumeration of subscription tiers."""

    free = "free"
    pro = "pro"
    business = "business"

    def default_credits(self) -> int:
        """Return the default monthly credit allocation for this tier."""
        if self is SubscriptionTier.free:
            return 3
        if self is SubscriptionTier.pro:
            return 100
        return 1000


class User(SQLModel, table=True):
    """Database model representing a user account."""

    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    email: EmailStr = Field(index=True, unique=True, nullable=False)
    hashed_password: str
    first_name: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # relationships
    projects: list["Project"] = Relationship(back_populates="user")
    subscription: Optional["Subscription"] = Relationship(back_populates="user")


class Project(SQLModel, table=True):
    """Database model representing a before/after render pair."""

    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", nullable=False)
    before_url: str
    after_url: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship(back_populates="projects")


class Subscription(SQLModel, table=True):
    """Database model representing a user's subscription status."""

    id: int = Field(default=None, primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", nullable=False, unique=True)
    stripe_sub_id: Optional[str] = Field(default=None)
    tier: SubscriptionTier = Field(sa_column_kwargs={"default": SubscriptionTier.free})
    renews_at: datetime = Field(default_factory=lambda: datetime.utcnow() + timedelta(days=30))
    credits_left: int = Field(default_factory=lambda: SubscriptionTier.free.default_credits())

    user: User = Relationship(back_populates="subscription")


class RenderJob(SQLModel, table=True):
    """Database model tracking asynchronous render jobs.

    This table stores a unique job ID along with the user who created it,
    the source image URL and the resulting render URL once complete. The
    status field indicates whether the job is pending, running, completed
    or failed. Jobs can be polled by the client to determine progress.
    """

    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", nullable=False)
    style: str  # the style prompt used for generation
    before_url: str
    after_url: Optional[str] = None
    status: str = Field(default="pending")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship()


# Pydantic models for request/response schemas

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    first_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserRead(BaseModel):
    id: uuid.UUID
    email: EmailStr
    first_name: Optional[str] = None
    created_at: datetime
    credits_left: int
    subscription_tier: SubscriptionTier

    class Config:
        orm_mode = True


class Token(BaseModel):
    access_token: str
    token_type: str


class ProjectRead(BaseModel):
    id: uuid.UUID
    before_url: str
    after_url: Optional[str] = None
    created_at: datetime

    class Config:
        orm_mode = True


class RenderRequest(BaseModel):
    style: str


class RenderStatus(BaseModel):
    job_id: uuid.UUID
    status: str
    after_url: Optional[str] = None


class CreateStripeSessionRequest(BaseModel):
    plan: SubscriptionTier


class StripeSessionResponse(BaseModel):
    checkout_url: str