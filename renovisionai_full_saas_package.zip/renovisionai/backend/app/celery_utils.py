"""
Celery application factory for RenovisionAI.

This module configures a Celery instance that workers and the main
application can import. It reads connection information from environment
variables. Celery is used for time‑consuming background tasks such as
image generation via Replicate.
"""
from __future__ import annotations

import os
from celery import Celery


def make_celery() -> Celery:
    """Create and return a configured Celery application."""
    broker_url = os.getenv("REDIS_URL", "redis://redis:6379/0")
    backend_url = os.getenv("REDIS_URL", "redis://redis:6379/0")
    celery = Celery(
        "renovisionai",
        broker=broker_url,
        backend=backend_url,
    )
    celery.conf.update(
        task_serializer="json",
        result_serializer="json",
        accept_content=["json"],
        timezone="UTC",
        enable_utc=True,
    )
    return celery


celery_app = make_celery()