"""
Celery tasks for RenovisionAI.

This module defines background tasks invoked by the API. The primary task
`generate_render` takes a job ID, fetches the corresponding job record from
the database, calls an external generative API (e.g., Replicate SDXL), saves
the result to storage and updates the job record with the resulting URL.

The current implementation stubs the actual generation with a placeholder
operation for demonstration. In a real deployment you would integrate the
Replicate SDK here using the REPLICATE_API_TOKEN【624640778666419†L406-L421】.
"""
from __future__ import annotations

import os
import time
import uuid
from typing import Optional

from sqlmodel import Session, select, SQLModel, create_engine

from .celery_utils import celery_app
from .models import RenderJob, Project


# Use a synchronous engine for Celery tasks; Celery processes cannot easily
# reuse the async engine from the main app. The DATABASE_URL may use
# psycopg2 driver which is synchronous by default.
SYNC_DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql+psycopg2://postgres:postgres@db:5432/renovision"
)
sync_engine = create_engine(SYNC_DATABASE_URL, echo=False)


@celery_app.task(name="generate_render")
def generate_render(job_id: str) -> Optional[str]:
    """Background task that performs the image generation.

    Args:
        job_id: The UUID of the RenderJob record as a string.

    Returns:
        The URL of the generated image if successful, otherwise None.
    """
    # Convert job_id to UUID
    try:
        job_uuid = uuid.UUID(job_id)
    except ValueError:
        return None

    with Session(sync_engine) as session:
        job = session.exec(select(RenderJob).where(RenderJob.id == job_uuid)).first()
        if job is None:
            return None

        # Mark as running
        job.status = "running"
        session.add(job)
        session.commit()

        # Simulate processing: sleep and copy the before URL to after URL
        time.sleep(5)

        # In a production implementation, call the Replicate API here
        # using the REPLICATE_API_TOKEN and upload the resulting image to
        # S3 or another storage service. For demonstration we simply
        # append a suffix to the before URL.
        before_url = job.before_url
        after_url = before_url  # In reality you would obtain a new URL

        job.after_url = after_url
        job.status = "completed"
        # Update timestamp to current UTC time
        from datetime import datetime
        job.updated_at = datetime.utcnow()
        session.add(job)

        # Create or update a Project record with this render
        project = session.exec(select(Project).where(Project.id == job.id)).first()
        if project is None:
            project = Project(
                id=job.id,
                user_id=job.user_id,
                before_url=before_url,
                after_url=after_url,
            )
        else:
            project.after_url = after_url
        session.add(project)
        session.commit()

        return after_url