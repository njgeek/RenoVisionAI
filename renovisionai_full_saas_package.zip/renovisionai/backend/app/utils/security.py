"""
Security helpers for hashing passwords and creating/verifying JWTs.

The functions defined here encapsulate the details of password hashing via
Passlib's bcrypt and JWT encoding/decoding via python‑jose. Secrets and
expiration times are read from environment variables.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from jose import JWTError, jwt
from passlib.context import CryptContext


# Context for hashing passwords using bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_password_hash(password: str) -> str:
    """Hash a plaintext password using bcrypt."""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plaintext password against a hashed value."""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict[str, Any], expires_delta: Optional[int] = None) -> str:
    """Create a JWT access token containing provided data and expiry.

    Args:
        data: Additional claims to embed in the token.
        expires_delta: Expiration time in minutes. If None, uses
            ACCESS_TOKEN_EXPIRE_MINUTES from the environment.

    Returns:
        Encoded JWT as a string.
    """
    to_encode = data.copy()
    secret_key = os.getenv("SECRET_KEY", "change-me")
    expire_minutes = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
    if expires_delta is not None:
        expire_minutes = expires_delta
    expire = datetime.now(timezone.utc) + timedelta(minutes=expire_minutes)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, secret_key, algorithm="HS256")


def decode_access_token(token: str) -> Optional[dict[str, Any]]:
    """Decode and validate a JWT access token.

    Returns the decoded payload if valid or None if invalid/expired.
    """
    secret_key = os.getenv("SECRET_KEY", "change-me")
    try:
        payload = jwt.decode(token, secret_key, algorithms=["HS256"])
        return payload
    except JWTError:
        return None