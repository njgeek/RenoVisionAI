"""
Stripe integration routes.

These endpoints provide subscription billing via Stripe Checkout. Clients
request a Checkout session URL for a given plan, then redirect the user to
Stripe. A webhook processes completed sessions and updates subscription
records accordingly.
"""
from __future__ import annotations

import os
from typing import Dict

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

import stripe

from ..database import get_session
from ..dependencies import get_current_user
from datetime import datetime, timedelta
from ..models import SubscriptionTier, User, Subscription, CreateStripeSessionRequest, StripeSessionResponse

router = APIRouter()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

# Map SubscriptionTier to Stripe price IDs. In production these values
# should be provided through environment variables or a database table.
PLAN_PRICE_MAP: Dict[SubscriptionTier, str] = {
    SubscriptionTier.pro: os.getenv("STRIPE_PRICE_PRO", "price_pro_placeholder"),
    SubscriptionTier.business: os.getenv("STRIPE_PRICE_BUSINESS", "price_business_placeholder"),
}


@router.post("/create-session", response_model=StripeSessionResponse)
async def create_checkout_session(
    request_body: CreateStripeSessionRequest,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> StripeSessionResponse:
    """Create a Stripe Checkout session for upgrading a user's plan."""
    tier = request_body.plan
    if tier == SubscriptionTier.free:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot purchase free plan")

    price_id = PLAN_PRICE_MAP.get(tier)
    if not price_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid plan")

    # Metadata used to identify user in webhook
    metadata = {"user_id": str(current_user.id), "tier": tier.value}

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{"price": price_id, "quantity": 1}],
            mode="subscription",
            metadata=metadata,
            success_url=os.getenv("SUCCESS_URL", "http://localhost:3000/dashboard?success=true"),
            cancel_url=os.getenv("CANCEL_URL", "http://localhost:3000/pricing?canceled=true"),
        )
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

    return StripeSessionResponse(checkout_url=checkout_session.url)


@router.post("/webhook")
async def stripe_webhook(request: Request, session: AsyncSession = Depends(get_session)) -> JSONResponse:
    """Handle Stripe webhook events."""
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET")
    event = None

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid signature")

    # Handle checkout.session.completed
    if event["type"] == "checkout.session.completed":
        data = event["data"]["object"]
        metadata = data.get("metadata", {})
        user_id = metadata.get("user_id")
        tier_value = metadata.get("tier")
        if user_id and tier_value:
            # Update subscription tier and credits
            result = await session.exec(select(User).where(User.id == user_id))
            user = result.first()
            if user:
                tier = SubscriptionTier(tier_value)
                await session.refresh(user, attribute_names=["subscription"])
                sub = user.subscription
                if sub is None:
                    sub = Subscription(user_id=user.id)
                sub.tier = tier
                sub.credits_left = tier.default_credits()
                sub.renews_at = datetime.utcnow() + timedelta(days=30)
                session.add(sub)
                await session.commit()
    return JSONResponse({"received": True})