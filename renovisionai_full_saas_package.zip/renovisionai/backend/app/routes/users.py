"""
User account routes.

Exposes an endpoint to retrieve details about the currently authenticated
user, including available credits and subscription tier.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

from ..database import get_session
from ..dependencies import get_current_user
from ..models import User, UserRead

router = APIRouter()


@router.get("/me", response_model=UserRead)
async def read_me(
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> UserRead:
    """Return information about the current user.

    This includes email, name, subscription tier, credits remaining and
    account creation timestamp.
    """
    # Retrieve up‑to‑date subscription record
    await session.refresh(current_user, attribute_names=["subscription"])
    sub = current_user.subscription
    credits_left = sub.credits_left if sub else 0
    tier = sub.tier if sub else None
    return UserRead(
        id=current_user.id,
        email=current_user.email,
        first_name=current_user.first_name,
        created_at=current_user.created_at,
        credits_left=credits_left,
        subscription_tier=tier,
    )