"""
Authentication routes for RenovisionAI.

These endpoints handle user registration and login using email and password.
Successful login returns a JWT token and sets it as an HTTP‑only cookie.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response, status
import os
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select

from ..database import get_session
from ..models import User, UserCreate, UserLogin, Subscription, SubscriptionTier, Token
from ..utils.security import get_password_hash, verify_password, create_access_token

router = APIRouter()

# Determine whether cookies should be marked as "secure" (HTTPS-only). During local development
# on http://localhost the cookie must not be secure, otherwise the browser will silently
# drop it. In production you should set COOKIE_SECURE=true in the environment.
SECURE_COOKIES: bool = os.getenv("COOKIE_SECURE", "false").lower() == "true"


@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
async def register(user_in: UserCreate, response: Response, session: AsyncSession = Depends(get_session)) -> Token:
    """Register a new user.

    Creates a new user account with the provided email and password. If an
    account already exists for that email, returns HTTP 400. Upon
    successful registration the user is automatically logged in and a
    JWT token is issued and set as a secure cookie.
    """
    # Check for existing user
    result = await session.exec(select(User).where(User.email == user_in.email))
    if result.first() is not None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

    hashed_pw = get_password_hash(user_in.password)
    user = User(email=user_in.email, hashed_password=hashed_pw, first_name=user_in.first_name)
    session.add(user)
    await session.flush()  # assign id before creating subscription

    # Create a subscription entry with default tier and credits
    subscription = Subscription(user_id=user.id, tier=SubscriptionTier.free)
    session.add(subscription)
    await session.commit()
    await session.refresh(user)

    # Issue token
    token = create_access_token({"sub": str(user.id)})
    response.set_cookie(
        key="access_token",
        value=f"Bearer {token}",
        httponly=True,
        secure=SECURE_COOKIES,
        samesite="lax",
        path="/",
    )
    return Token(access_token=token, token_type="bearer")


@router.post("/jwt/login", response_model=Token)
async def login(user_in: UserLogin, response: Response, session: AsyncSession = Depends(get_session)) -> Token:
    """Authenticate a user and return a JWT token.

    Checks the provided credentials against the database and issues a JWT
    token if valid. The token is also set as an HTTP‑only cookie.
    """
    result = await session.exec(select(User).where(User.email == user_in.email))
    user = result.first()
    if user is None or not verify_password(user_in.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    token = create_access_token({"sub": str(user.id)})
    response.set_cookie(
        key="access_token",
        value=f"Bearer {token}",
        httponly=True,
        secure=SECURE_COOKIES,
        samesite="lax",
        path="/",
    )
    return Token(access_token=token, token_type="bearer")