# RenovisionAI

RenovisionAI is a proof‑of‑concept software‑as‑a‑service (SaaS) that lets homeowners and contractors preview photorealistic makeovers of their rooms before any construction begins. It combines a modern TypeScript/React front‑end with a Python FastAPI back‑end, asynchronous Celery workers and Stripe billing. The design follows recognised SaaS architecture principles such as designing for scalability, breaking the system into modular services and implementing robust security measures【624640778666419†L404-L423】【624640778666419†L468-L472】.

## Features

### Generative AI

* Upload an interior photograph and choose a style (e.g., Modern, Rustic). A Celery task simulates calling a generative model (Stable Diffusion XL via Replicate) and returns a photorealistic "after" render. Replace the stubbed implementation in `backend/app/tasks.py` with a real call to the Replicate API.

### Authentication

* Email + password registration and login.
* JWT tokens stored in an HTTP‑only cookie for secure authentication.

### Plans & Billing

* Free tier with 3 renders per month, Pro (€29/mo, 100 renders) and Business (€99/mo, 1 000 renders).
* Stripe Checkout integration: selecting a paid plan redirects users to Stripe and, upon completion, updates their subscription tier and credits via the webhook handler.

### Dashboard

* Authenticated users can view their current subscription tier, remaining credits and a gallery of before/after pairs.
* Upload new photos and initiate renders directly from the dashboard.

### Landing and Pricing

* A marketing homepage with hero section, sample before/after slider and testimonials.
* Pricing page displaying plan options and allowing users to upgrade via Stripe.

### Admin (placeholder)

* The specification includes an admin panel concept; this proof‑of‑concept does not yet include those routes.

## Tech Stack

* **Front‑end:** Next.js 14 (App Router), TypeScript, Tailwind CSS.
* **Back‑end:** FastAPI (ASGI), SQLModel (SQLAlchemy 2), Celery workers (Redis broker).
* **Database:** PostgreSQL 16.
* **Queue:** Redis 7.
* **Storage:** Local filesystem by default; replace with AWS S3 or Cloudflare R2 by supplying `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` and `S3_BUCKET_NAME` in `.env`.
* **Billing:** Stripe Checkout and webhooks.

## Architecture

The system consists of three main services orchestrated via Docker Compose:

* **backend** – A FastAPI application exposing REST endpoints for authentication, rendering and billing. It uses SQLModel to define models and interacts with PostgreSQL asynchronously.
* **worker** – A Celery worker that processes long‑running image generation tasks. It reads jobs from Redis and updates the database when complete.
* **frontend** – A Next.js application that renders server‑side pages and communicates with the backend via REST. It uses Tailwind for styling and includes components for upload widgets, before/after sliders, dark mode and Stripe integration.

These services follow a microservice pattern, enabling independent scaling and deployment【624640778666419†L404-L423】.  CORS settings restrict API access to configured origins, and JWT cookies provide secure authentication【624640778666419†L468-L472】.

## Running Locally

1. Clone the repository and navigate into it:

   ```bash
   git clone <repo-url>
   cd renovisionai
   ```

2. Copy environment examples and fill in secrets:

   ```bash
   cp backend/.env.example backend/.env
   cp frontend/.env.local.example frontend/.env.local
   # Edit backend/.env and frontend/.env.local with your keys
   ```

3. Build and start the stack with Docker Compose:

   ```bash
   docker compose up -d --build
   ```

   The front‑end will be available at `http://localhost:3000` and the back‑end at `http://localhost:8000`.

4. Optional: To initialise the database outside of Docker, run:

   ```bash
   docker compose run --rm backend python backend/init_db.py
   ```

## Development Notes

* **Generative AI integration:** The `generate_render` task is currently stubbed. To enable real image generation, install the [Replicate](https://replicate.com/) SDK and call the SDXL model inside the task.
* **NextAuth integration:** Authentication is implemented manually via JWT cookies for simplicity. You can integrate NextAuth.js and Next.js route handlers for a more complete solution.
* **Admin panel:** The specification references an admin panel to view usage and subscriptions. This proof‑of‑concept leaves that as an exercise for further development.

## Future Improvements

* Replace local file storage with S3 or Cloudflare R2.
* Add email verification and password reset flows.
* Implement role‑based access control for the admin panel.
* Write unit and integration tests for all API endpoints.
* Deploy to a platform such as Coolify with CI/CD pipelines.