"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

interface AdminUser {
  id: string;
  email: string;
  first_name: string | null;
  created_at: string;
  subscription_tier: string;
  credits_left: number;
}

interface Stats {
  user_count: number;
  project_count: number;
  render_job_count: number;
}

export default function AdminPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState('');
  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL;
        const userRes = await axios.get(`${apiBase}/admin/users`, { withCredentials: true });
        setUsers(userRes.data);
        const statsRes = await axios.get(`${apiBase}/admin/stats`, { withCredentials: true });
        setStats(statsRes.data);
      } catch (err: any) {
        // If unauthorized, redirect to login
        if (err?.response?.status === 401 || err?.response?.status === 403) {
          setError('You do not have permission to view this page.');
          router.push('/login');
        } else {
          setError('Failed to load admin data');
        }
      }
    };
    fetchData();
  }, [router]);

  if (error) {
    return <p className="text-center text-red-500 mt-8">{error}</p>;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-center">Admin Dashboard</h1>
      {stats && (
        <div className="grid md:grid-cols-3 gap-4">
          <div className="p-4 border rounded-lg dark:border-gray-700 text-center">
            <p className="text-2xl font-semibold">{stats.user_count}</p>
            <p className="text-sm">Users</p>
          </div>
          <div className="p-4 border rounded-lg dark:border-gray-700 text-center">
            <p className="text-2xl font-semibold">{stats.project_count}</p>
            <p className="text-sm">Projects</p>
          </div>
          <div className="p-4 border rounded-lg dark:border-gray-700 text-center">
            <p className="text-2xl font-semibold">{stats.render_job_count}</p>
            <p className="text-sm">Render Jobs</p>
          </div>
        </div>
      )}
      <div>
        <h2 className="text-2xl font-semibold mb-4">Users</h2>
        <div className="overflow-auto rounded-lg border dark:border-gray-700">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800">
              <tr>
                <th className="px-4 py-2 text-left font-medium text-gray-700 dark:text-gray-200">Email</th>
                <th className="px-4 py-2 text-left font-medium text-gray-700 dark:text-gray-200">Name</th>
                <th className="px-4 py-2 text-left font-medium text-gray-700 dark:text-gray-200">Created</th>
                <th className="px-4 py-2 text-left font-medium text-gray-700 dark:text-gray-200">Tier</th>
                <th className="px-4 py-2 text-left font-medium text-gray-700 dark:text-gray-200">Credits</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {users.map((u) => (
                <tr key={u.id} className="bg-white dark:bg-gray-900">
                  <td className="px-4 py-2 whitespace-nowrap">{u.email}</td>
                  <td className="px-4 py-2 whitespace-nowrap">{u.first_name ?? '-'}</td>
                  <td className="px-4 py-2 whitespace-nowrap">{new Date(u.created_at).toLocaleString()}</td>
                  <td className="px-4 py-2 whitespace-nowrap capitalize">{u.subscription_tier}</td>
                  <td className="px-4 py-2 whitespace-nowrap">{u.credits_left}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}