"use client";

// This file uses React hooks and event handlers; designate it as a client component.

import { loadStripe } from '@stripe/stripe-js';
import { Stripe } from '@stripe/stripe-js';
import axios from 'axios';

const plans = [
  {
    name: 'Free',
    price: '$0/mo',
    credits: 3,
    tier: 'free',
    features: ['3 renders per month', 'Access to basic styles'],
  },
  {
    name: 'Pro',
    price: '$29/mo',
    credits: 100,
    tier: 'pro',
    features: ['100 renders per month', 'Priority rendering', 'Premium styles'],
  },
  {
    name: 'Business',
    price: '$99/mo',
    credits: 1000,
    tier: 'business',
    features: ['1,000 renders per month', 'Fastest rendering', 'All styles'],
  },
];

const PricingPage = () => {
  const handlePurchase = async (plan: string) => {
    try {
      const stripePromise: Promise<Stripe | null> = loadStripe(
        process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY || ''
      );
      const stripe = await stripePromise;
      const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL;
      const res = await axios.post(
        `${apiBase}/stripe/create-session`,
        { plan },
        { withCredentials: true }
      );
      const checkoutUrl = res.data.checkout_url;
      if (stripe) {
        window.location.href = checkoutUrl;
      }
    } catch (error) {
      console.error('Error creating checkout session', error);
    }
  };
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-center mb-4">Choose Your Plan</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className={`relative border rounded-lg p-6 flex flex-col justify-between dark:border-gray-700 ${
              plan.tier === 'pro' ? 'ring-2 ring-primary dark:ring-accent' : ''
            }`}
          >
            {/* Highlight label for the most popular plan */}
            {plan.tier === 'pro' && (
              <span className="absolute -top-3 right-3 bg-primary dark:bg-accent text-white text-xs font-semibold px-2 py-1 rounded-full shadow">
                Most Popular
              </span>
            )}
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">{plan.name}</h2>
              <p className="text-3xl font-extrabold">{plan.price}</p>
              <ul className="mt-3 space-y-1 text-sm">
                {plan.features.map((feat) => (
                  <li key={feat}>• {feat}</li>
                ))}
              </ul>
            </div>
            <button
              onClick={() => plan.tier !== 'free' && handlePurchase(plan.tier)}
              className={`mt-6 w-full px-4 py-2 rounded text-white ${
                plan.tier === 'free' ? 'bg-gray-400 cursor-not-allowed' : 'bg-primary hover:bg-blue-600'
              }`}
              disabled={plan.tier === 'free'}
            >
              {plan.tier === 'free' ? 'Included' : 'Upgrade'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PricingPage;