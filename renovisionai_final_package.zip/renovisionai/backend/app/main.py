"""
Main entrypoint for the RenovisionAI backend.

This module configures the FastAPI application, connects to the database,
initialises Celery and registers all API routes. Configuration values are
primarily read from environment variables defined in `.env` and `.env.example`.

The application provides authentication, project management, render job
submission, Stripe billing and auxiliary endpoints. See the README for more
details on available routes and how to run the service.

References on SaaS best practices such as scalable microservice architecture
and security measures are drawn from Binadox's overview of SaaS architecture,
which emphasises designing for scalability, implementing robust security
controls and exposing well‑defined APIs【624640778666419†L404-L423】. These
principles underpin the design of this backend service.
"""

from __future__ import annotations

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from .database import create_db_and_tables
from .routes import auth, users, projects, render, stripe, admin


def get_allowed_origins() -> list[str]:
    """Parse the comma‑separated list of allowed origins from the
    environment. Defaults to localhost if not provided."""
    origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000")
    return [origin.strip() for origin in origins.split(",") if origin.strip()]


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    # Load environment variables from .env if present
    load_dotenv()
    app = FastAPI(title="RenovisionAI Backend", version="0.1.0")

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=get_allowed_origins(),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Create database tables on startup
    @app.on_event("startup")
    async def on_startup() -> None:
        await create_db_and_tables()

    # Include API routers
    app.include_router(auth.router, prefix="/auth", tags=["auth"])
    app.include_router(users.router, tags=["users"])
    app.include_router(projects.router, tags=["projects"])
    app.include_router(render.router, tags=["render"])
    app.include_router(stripe.router, prefix="/stripe", tags=["stripe"])
    app.include_router(admin.router, prefix="/admin", tags=["admin"])

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=os.getenv("API_HOST", "0.0.0.0"),
        port=int(os.getenv("API_PORT", "8000")),
        reload=True,
    )