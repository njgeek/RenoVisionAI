"""
Database utilities for RenovisionAI.

This module defines the asynchronous database engine and sessionmaker using
SQLModel and SQLAlchemy. It provides a dependency for obtaining a session and
function to create database tables on startup. The database URL is read from
the `DATABASE_URL` environment variable.
"""
from __future__ import annotations

import os
from typing import AsyncGenerator

from sqlmodel import SQLModel
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

# Construct the async database URL. SQLModel currently uses SQLAlchemy under
# the hood; when using async drivers we need to specify asyncpg or similar.
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://postgres:postgres@db:5432/renovision",
)

# Create an asynchronous engine. The pool size and other parameters can be
# customised via environment variables if needed for scalability【624640778666419†L404-L421】.
engine = create_async_engine(DATABASE_URL, future=True, echo=False)

# Create a sessionmaker for producing AsyncSession objects
async_session_maker: sessionmaker[AsyncSession] = sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)


async def create_db_and_tables() -> None:
    """Create database tables based on the SQLModel models.

    This function is invoked on application startup. It introspects all
    subclasses of SQLModel and creates the corresponding tables if they do
    not already exist. In a production environment you would typically use
    migration tools such as Alembic instead of automatic creation.
    """
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """Yield an AsyncSession for use in request handlers.

    This dependency can be injected into FastAPI route handlers. It ensures
    that sessions are properly closed after use.
    """
    async with async_session_maker() as session:
        yield session