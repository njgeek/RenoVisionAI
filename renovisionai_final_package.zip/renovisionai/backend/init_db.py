"""
Utility script to initialise the database tables.

This script can be run locally to create database tables for development.
It uses the same SQLModel metadata as the FastAPI app. In production
environments you would typically rely on migrations (e.g. Alembic).
"""
from app.database import engine
from app.models import SQLModel

def main() -> None:
    SQLModel.metadata.create_all(engine)
    print("Database tables created.")


if __name__ == "__main__":
    main()